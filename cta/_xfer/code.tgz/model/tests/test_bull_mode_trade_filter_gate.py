from __future__ import annotations

import pandas as pd

from cta.config.model_oot_eval_config import OotEvaluationConfig
from cta.model.oot.oot_trade_filter_gate import apply_trade_filter_gate


def _base_df() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "symbol": ["IF0", "IF0"],
            "exchange": ["CFFEX", "CFFEX"],
            "interval": ["day", "day"],
            "side": ["long", "short"],
            "bull_mode": ["attack", "attack"],
            "trade_filter_prob": [0.55, 0.55],
            "trade_filter_prob_pctl": [75.0, 75.0],
        }
    )


def test_trade_filter_gate_supports_side_bull_mode_threshold_adjustment() -> None:
    df = _base_df()
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_percentile_threshold_attack_long_delta=-5.0,
        trade_filter_percentile_threshold_attack_short_delta=10.0,
    )
    gate = pd.Series([True, True], index=df.index, dtype=bool)
    block = pd.Series(["", ""], index=df.index, dtype=object)

    out, gate_out, block_out = apply_trade_filter_gate(
        df,
        cfg=cfg,
        gate_by_legacy=gate,
        model_block_reason=block,
    )

    assert bool(gate_out.iloc[0]) is True
    assert bool(gate_out.iloc[1]) is False
    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 65.0
    assert float(out.iloc[1]["trade_filter_gate_threshold"]) == 80.0
    assert str(block_out.iloc[1]) == "blocked_trade_filter"


def test_trade_filter_gate_supports_explicit_cluster_interval_side_bull_override() -> None:
    df = _base_df()
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_percentile_threshold_by_cluster_interval_side_bull_mode={
            "index|day|long|attack": 77.0,
            "index|day|short|attack": 72.0,
        },
    )
    gate = pd.Series([True, True], index=df.index, dtype=bool)
    block = pd.Series(["", ""], index=df.index, dtype=object)

    out, gate_out, _block_out = apply_trade_filter_gate(
        df,
        cfg=cfg,
        gate_by_legacy=gate,
        model_block_reason=block,
    )

    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 77.0
    assert float(out.iloc[1]["trade_filter_gate_threshold"]) == 72.0
    assert bool(gate_out.iloc[0]) is False
    assert bool(gate_out.iloc[1]) is True


def test_trade_filter_gate_blocks_cross_sectional_when_bypass_not_configured() -> None:
    """H4 回归：默认 trade_filter_bypass_signal_types=() → rotation 信号同样被 gate。"""
    df = _base_df().iloc[[0]].copy()
    df["signal_type"] = "cross_sectional_momentum"
    df["bull_mode"] = "normal"
    df["trade_filter_prob_pctl"] = 10.0
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
    )
    # 默认 bypass 元组为空
    assert cfg.trade_filter_bypass_signal_types == ()
    gate = pd.Series([True], index=df.index, dtype=bool)
    block = pd.Series([""], index=df.index, dtype=object)

    _out, gate_out, _block_out = apply_trade_filter_gate(
        df, cfg=cfg, gate_by_legacy=gate, model_block_reason=block,
    )
    # 10 < 70 → 应被拦截
    assert bool(gate_out.iloc[0]) is False


def test_trade_filter_gate_bypasses_cross_sectional_rotation_signal() -> None:
    """显式 opt-in bypass 时，rotation 信号绕过 trade-filter gate。"""
    df = _base_df().iloc[[0]].copy()
    df["signal_type"] = "cross_sectional_momentum"
    df["bull_mode"] = "normal"
    df["trade_filter_prob_pctl"] = 10.0
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_bypass_signal_types=("cross_sectional_momentum",),  # 显式启用
    )
    gate = pd.Series([True], index=df.index, dtype=bool)
    block = pd.Series([""], index=df.index, dtype=object)

    out, gate_out, block_out = apply_trade_filter_gate(
        df, cfg=cfg, gate_by_legacy=gate, model_block_reason=block,
    )

    assert bool(gate_out.iloc[0]) is True
    assert str(block_out.iloc[0]) == ""
    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 76.0


def test_trade_filter_gate_bypasses_spread_arbitrage_signal() -> None:
    """spread_arbitrage 可显式加入 bypass 列表，避免重复被 trade-filter 拦截。"""
    df = _base_df().iloc[[0]].copy()
    df["signal_type"] = "spread_arbitrage"
    df["bull_mode"] = "normal"
    df["trade_filter_prob_pctl"] = 10.0
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_bypass_signal_types=("spread_arbitrage",),
    )
    gate = pd.Series([True], index=df.index, dtype=bool)
    block = pd.Series([""], index=df.index, dtype=object)

    out, gate_out, block_out = apply_trade_filter_gate(
        df, cfg=cfg, gate_by_legacy=gate, model_block_reason=block,
    )

    assert bool(gate_out.iloc[0]) is True
    assert str(block_out.iloc[0]) == ""
    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 70.0


def test_trade_filter_gate_supports_signal_type_threshold_delta() -> None:
    df = pd.DataFrame(
        {
            "symbol": ["IF0", "IF0", "IF0"],
            "exchange": ["CFFEX", "CFFEX", "CFFEX"],
            "interval": ["day", "day", "day"],
            "side": ["long", "long", "long"],
            "bull_mode": ["normal", "normal", "normal"],
            "trade_filter_prob": [0.70, 0.70, 0.70],
            "trade_filter_prob_pctl": [70.0, 70.0, 70.0],
            "signal_type": [
                "bull_pullback_continuation",
                "breakout_pullback_continuation",
                "trend_acceleration_breakout",
            ],
        }
    )
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_percentile_threshold_delta_by_signal_type={
            "bull_pullback_continuation": -5.0,
            "breakout_pullback_continuation": -3.0,
            "trend_acceleration_breakout": 5.0,
        },
    )
    gate = pd.Series([True, True, True], index=df.index, dtype=bool)
    block = pd.Series(["", "", ""], index=df.index, dtype=object)

    out, gate_out, _block_out = apply_trade_filter_gate(
        df,
        cfg=cfg,
        gate_by_legacy=gate,
        model_block_reason=block,
    )

    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 65.0
    assert float(out.iloc[1]["trade_filter_gate_threshold"]) == 67.0
    assert float(out.iloc[2]["trade_filter_gate_threshold"]) == 75.0
    assert bool(gate_out.iloc[0]) is True
    assert bool(gate_out.iloc[1]) is True
    assert bool(gate_out.iloc[2]) is False


def test_trade_filter_gate_supports_signal_type_interval_threshold_delta() -> None:
    df = pd.DataFrame(
        {
            "symbol": ["IF0", "IF0"],
            "exchange": ["CFFEX", "CFFEX"],
            "interval": ["day", "60min"],
            "side": ["long", "long"],
            "bull_mode": ["normal", "normal"],
            "trade_filter_prob": [0.70, 0.70],
            "trade_filter_prob_pctl": [70.0, 70.0],
            "signal_type": [
                "bull_pullback_continuation",
                "bull_pullback_continuation",
            ],
        }
    )
    cfg = OotEvaluationConfig(
        use_trade_filter_gate=True,
        trade_filter_gate_mode="cluster_interval_percentile",
        trade_filter_percentile_threshold=70.0,
        trade_filter_percentile_threshold_delta_by_signal_type={
            "bull_pullback_continuation": -5.0,
        },
        trade_filter_percentile_threshold_delta_by_signal_type_interval={
            "bull_pullback_continuation|day": 8.0,
        },
    )
    gate = pd.Series([True, True], index=df.index, dtype=bool)
    block = pd.Series(["", ""], index=df.index, dtype=object)

    out, gate_out, _block_out = apply_trade_filter_gate(
        df,
        cfg=cfg,
        gate_by_legacy=gate,
        model_block_reason=block,
    )

    assert float(out.iloc[0]["trade_filter_gate_threshold"]) == 73.0
    assert float(out.iloc[1]["trade_filter_gate_threshold"]) == 65.0
    assert bool(gate_out.iloc[0]) is False
    assert bool(gate_out.iloc[1]) is True
